#include "debug.h"
int new_counter=0;
int delete_counter=0;




